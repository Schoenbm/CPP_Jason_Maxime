#pragma once

#include "box2d.hh"
#include "point2d.hh"

#include <cstddef> // std::size_t


class box2d_iterator {
public:
  box2d_iterator()                      = default;
  box2d_iterator(const box2d_iterator&) = default;
  box2d_iterator& operator=(const box2d_iterator&) = default;

  explicit box2d_iterator(const box2d& d);

  void start();
  bool is_valid() const;
  void next();

  operator point2d() const;

private:
  // todo
};
