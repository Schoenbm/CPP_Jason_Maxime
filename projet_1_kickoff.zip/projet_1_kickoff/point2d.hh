#pragma once

#include <iosfwd> // std::ostream fwd declaration
 // todo