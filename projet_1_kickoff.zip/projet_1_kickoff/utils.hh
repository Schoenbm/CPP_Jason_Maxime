#pragma once

#include <algorithm> // std::max
#include <cstddef>   // std::size_t
#include <iomanip>   // std::setw
#include <ostream>   // std::ostream
#include <sstream>   // std::ostringstream


namespace utils {
// Compute the maximum value of an image
// todo

// Compute the minimum value of an image
// todo

// todo: Functions for printing

}

} // namespace utils
